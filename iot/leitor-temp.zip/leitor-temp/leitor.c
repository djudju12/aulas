#define ROW_1     0x80
#define ROW_2     0xC0
#define CLEAR     0x01
#define CUR_OFF   0x0C
#define CUR_ON    0x0E
#define CUR_BLINK 0x0F
#define ZERO      0x30

#define D7 7
#define D6 6
#define D5 5
#define D4 4
#define D3 3
#define D2 2
#define D1 1
#define D0 0
#define TP A0

#define RS 8
#define EN 9

#define CMD   LOW
#define WRITE HIGH

void load(int type, byte b)
{
  if (type != CMD && type != WRITE) 
    return;
  
  digitalWrite(RS, type);
  digitalWrite(EN, HIGH);
  
  digitalWrite(D0, b&1);
  digitalWrite(D1, b&2);
  digitalWrite(D2, b&4);
  digitalWrite(D3, b&8);
  digitalWrite(D4, b&16);
  digitalWrite(D5, b&32);
  digitalWrite(D6, b&64);
  digitalWrite(D7, b&128);
  
  delay(2);
  digitalWrite(EN, LOW);
  delay(2);
}

void write_str(char* s)
{
  while(*s)
    load(WRITE, *s++);
}

byte toByte(int n)
{
  return n+ZERO;
}

void write_num(int num)
{
  if (num < 0)
    load(WRITE, 0x2D);
  
  num = abs(num);
  if (num < 10)
  {
    load(WRITE, 0x30);
  	load(WRITE, toByte(num));
  } 
  else if (num < 100) {
  	int first_number = num / 10;
  	int second_number = num % 10;
  	load(WRITE, toByte(first_number));
  	load(WRITE, toByte(second_number));
  }
  else if (num < 1000) {
    int first_number = num / 100;
  	int second_number = (num % 100) / 10;
    int third_number = (num % 100) % 10;
  	load(WRITE, toByte(first_number));
  	load(WRITE, toByte(second_number));
    load(WRITE, toByte(third_number));
  }
  else {
  	error("-999 > n < 999");
  }
}

void clear()
{
  load(CMD, CLEAR);
}

void error(char *msg)
{
  clear();
  load(CMD, ROW_1);
  write_str("error:");
  load(CMD, ROW_2);
  write_str(msg);
}

void lcd_init()
{
  load(CMD, 0x38);
  delay(5);
  load(CMD, 0x38);
  delay(1);
  load(CMD, 0x38);
  load(CMD, 0x06);
  load(CMD, 0x0E);
  load(CMD, 0x01);
  delay(5);
}

void setup()
{
  pinMode(D7, OUTPUT);
  pinMode(D6, OUTPUT);
  pinMode(D5, OUTPUT);
  pinMode(D4, OUTPUT);
  pinMode(D3, OUTPUT);
  pinMode(D2, OUTPUT);
  pinMode(D1, OUTPUT);
  pinMode(D0, OUTPUT);
  pinMode(RS, OUTPUT);
  pinMode(EN, OUTPUT);
  
  lcd_init();
  load(CMD, 0x87);
  load(WRITE, 0x30);
  clear();
  write_str("Temperatura: ");
}

int read_temp()
{
  int temp = analogRead(TP);
  temp -= 100;
  temp /= 2.04;
  return temp;
}

void loop()
{
  load(CMD, ROW_2);
  int temp = read_temp();
  write_num(temp);
  write_str(" C");
  delay(1000);
}